# multi_robot
multi_robot control and navigation system
this package can run in real NanoRobot/NanoCar/4WD/4WD_OMNI robot and robot_simulation

